<?php
/**
 * Chat Bot screen — editable bot settings + keyword answers on top,
 * conversation monitor (grouped by visitor session) below with search,
 * lead filter, stats and CSV export.
 *
 * Variables: $settings (array), $paged (int), $search (string),
 * $leads (bool), $stats (array).
 *
 * @package ARC_Starter_Templates
 */

defined( 'ABSPATH' ) || exit;

$conversations = Arc_ST_Chat::conversations( $paged, 20, $search, $leads );
$total         = Arc_ST_Chat::conversation_count( $search, $leads );
$pages         = max( 1, (int) ceil( $total / 20 ) );
?>
<div class="wrap">
	<h1 class="wp-heading-inline"><?php esc_html_e( 'Chat Bot', 'arc-starter-templates' ); ?></h1>
	<hr class="wp-header-end" />

	<?php if ( isset( $_GET['arc_chat_saved'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Chat settings saved.', 'arc-starter-templates' ); ?></p></div>
	<?php endif; ?>
	<?php if ( isset( $_GET['arc_chat_cleared'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Conversation log cleared.', 'arc-starter-templates' ); ?></p></div>
	<?php endif; ?>
	<?php if ( isset( $_GET['arc_chat_deleted'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Conversation deleted.', 'arc-starter-templates' ); ?></p></div>
	<?php endif; ?>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php wp_nonce_field( 'arc_st_chat_save' ); ?>
		<input type="hidden" name="action" value="arc_st_chat_save" />

		<h2><?php esc_html_e( 'Bot settings', 'arc-starter-templates' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><?php esc_html_e( 'Enabled', 'arc-starter-templates' ); ?></th>
				<td>
					<label>
						<input type="checkbox" name="chat_enabled" value="1" <?php checked( (int) $settings['enabled'], 1 ); ?> />
						<?php esc_html_e( 'Show the floating chat on imported template pages', 'arc-starter-templates' ); ?>
					</label>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="chat_title"><?php esc_html_e( 'Chat title', 'arc-starter-templates' ); ?></label></th>
				<td><input type="text" id="chat_title" name="chat_title" class="regular-text" value="<?php echo esc_attr( $settings['title'] ); ?>" /></td>
			</tr>
			<tr>
				<th scope="row"><label for="chat_greeting"><?php esc_html_e( 'Greeting message', 'arc-starter-templates' ); ?></label></th>
				<td><textarea id="chat_greeting" name="chat_greeting" class="large-text" rows="2"><?php echo esc_textarea( $settings['greeting'] ); ?></textarea>
					<p class="description"><?php esc_html_e( 'First message the visitor sees when the chat opens.', 'arc-starter-templates' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="chat_fallback"><?php esc_html_e( 'Fallback answer', 'arc-starter-templates' ); ?></label></th>
				<td><textarea id="chat_fallback" name="chat_fallback" class="large-text" rows="2"><?php echo esc_textarea( $settings['fallback'] ); ?></textarea>
					<p class="description"><?php esc_html_e( 'Sent when no keyword matches the visitor message.', 'arc-starter-templates' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="chat_retention"><?php esc_html_e( 'Log retention', 'arc-starter-templates' ); ?></label></th>
				<td>
					<select id="chat_retention" name="chat_retention">
						<?php foreach ( array( 0, 30, 90, 180, 365 ) as $d ) : ?>
						<option value="<?php echo (int) $d; ?>" <?php selected( (int) $settings['retention'], $d ); ?>>
							<?php echo 0 === $d ? esc_html__( 'Keep forever', 'arc-starter-templates' ) : esc_html( sprintf( /* translators: %d: days. */ __( 'Delete after %d days', 'arc-starter-templates' ), $d ) ); ?>
						</option>
						<?php endforeach; ?>
					</select>
					<p class="description"><?php esc_html_e( 'A daily cron drops log rows older than this. Limiting retention reduces stored visitor data.', 'arc-starter-templates' ); ?></p>
				</td>
			</tr>
		</table>

		<h2><?php esc_html_e( 'Default answers', 'arc-starter-templates' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Each row maps keywords (comma separated) to the reply the bot sends. Matching is case-insensitive; the row with the most keyword hits wins.', 'arc-starter-templates' ); ?></p>
		<table class="widefat striped" id="arc-chat-pairs" style="max-width:960px">
			<thead>
				<tr>
					<th style="width:38%"><?php esc_html_e( 'Keywords', 'arc-starter-templates' ); ?></th>
					<th><?php esc_html_e( 'Answer', 'arc-starter-templates' ); ?></th>
					<th style="width:40px"></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $settings['pairs'] as $pair ) : ?>
				<tr>
					<td><input type="text" name="chat_kw[]" class="large-text" value="<?php echo esc_attr( $pair['kw'] ); ?>" placeholder="price, pricing, cost" /></td>
					<td><textarea name="chat_a[]" class="large-text" rows="2"><?php echo esc_textarea( $pair['a'] ); ?></textarea></td>
					<td><button type="button" class="button arc-chat-del" aria-label="<?php esc_attr_e( 'Remove', 'arc-starter-templates' ); ?>">&times;</button></td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<p><button type="button" class="button" id="arc-chat-add">+ <?php esc_html_e( 'Add answer', 'arc-starter-templates' ); ?></button></p>

		<p class="submit"><button type="submit" class="button button-primary"><?php esc_html_e( 'Save chat settings', 'arc-starter-templates' ); ?></button></p>
	</form>

	<h2><?php esc_html_e( 'Test the bot', 'arc-starter-templates' ); ?></h2>
	<p class="description"><?php esc_html_e( 'Try a visitor message against the keyword table above — unsaved edits count.', 'arc-starter-templates' ); ?></p>
	<p style="max-width:960px;display:flex;gap:8px">
		<input type="text" id="arc-chat-test-in" class="regular-text" style="flex:1" placeholder="<?php esc_attr_e( 'e.g. is the service available?', 'arc-starter-templates' ); ?>" />
		<button type="button" class="button" id="arc-chat-test-run"><?php esc_html_e( 'Test', 'arc-starter-templates' ); ?></button>
	</p>
	<div id="arc-chat-test-out" style="max-width:960px"></div>

	<hr />
	<h2 class="wp-heading-inline"><?php esc_html_e( 'Conversations', 'arc-starter-templates' ); ?></h2>
	<span style="margin-left:8px;color:#646970">
		<?php echo esc_html( sprintf( /* translators: %d: conversation count. */ __( '%d sessions', 'arc-starter-templates' ), $total ) ); ?>
	</span>

	<p style="display:flex;gap:18px;flex-wrap:wrap;margin:14px 0 4px;max-width:960px">
		<span><strong><?php echo esc_html( number_format_i18n( $stats['sessions'] ) ); ?></strong> <?php esc_html_e( 'sessions', 'arc-starter-templates' ); ?></span>
		<span><strong><?php echo esc_html( number_format_i18n( $stats['messages'] ) ); ?></strong> <?php esc_html_e( 'messages', 'arc-starter-templates' ); ?></span>
		<span><strong><?php echo esc_html( number_format_i18n( $stats['leads'] ) ); ?></strong> <?php esc_html_e( 'leads (left email)', 'arc-starter-templates' ); ?></span>
		<span><strong><?php echo esc_html( number_format_i18n( $stats['today'] ) ); ?></strong> <?php esc_html_e( 'messages today', 'arc-starter-templates' ); ?></span>
	</p>

	<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" style="display:flex;gap:8px;align-items:center;margin:8px 0 14px;max-width:960px">
		<input type="hidden" name="page" value="<?php echo esc_attr( Arc_ST_Chat::PAGE ); ?>" />
		<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" class="regular-text" style="flex:1"
			placeholder="<?php esc_attr_e( 'Search session, message or email…', 'arc-starter-templates' ); ?>" />
		<label style="white-space:nowrap">
			<input type="checkbox" name="leads" value="1" <?php checked( $leads ); ?> />
			<?php esc_html_e( 'Leads only', 'arc-starter-templates' ); ?>
		</label>
		<button type="submit" class="button"><?php esc_html_e( 'Filter', 'arc-starter-templates' ); ?></button>
		<?php if ( '' !== $search || $leads ) : ?>
			<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=' . Arc_ST_Chat::PAGE ) ); ?>"><?php esc_html_e( 'Reset', 'arc-starter-templates' ); ?></a>
		<?php endif; ?>
		<a class="button" style="margin-left:auto" href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'arc_st_chat_export', 's' => $search, 'leads' => $leads ? 1 : 0 ), admin_url( 'admin-post.php' ) ), 'arc_st_chat_export' ) ); ?>">
			<?php esc_html_e( 'Export CSV', 'arc-starter-templates' ); ?>
		</a>
		<a class="button button-link-delete" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=arc_st_chat_clear' ), 'arc_st_chat_clear' ) ); ?>"
			onclick="return confirm('<?php echo esc_js( __( 'Delete ALL chat logs? This cannot be undone.', 'arc-starter-templates' ) ); ?>');">
			<?php esc_html_e( 'Clear all', 'arc-starter-templates' ); ?>
		</a>
	</form>

	<?php if ( empty( $conversations ) ) : ?>
		<p><?php echo '' !== $search || $leads ? esc_html__( 'No conversations match the current filters.', 'arc-starter-templates' ) : esc_html__( 'No conversations yet — they appear here once visitors use the chat on an imported page.', 'arc-starter-templates' ); ?></p>
	<?php else : ?>
		<table class="widefat striped" style="max-width:960px">
			<thead>
				<tr>
					<th style="width:140px"><?php esc_html_e( 'Session', 'arc-starter-templates' ); ?></th>
					<th style="width:140px"><?php esc_html_e( 'Last activity', 'arc-starter-templates' ); ?></th>
					<th style="width:160px"><?php esc_html_e( 'Page', 'arc-starter-templates' ); ?></th>
					<th style="width:170px"><?php esc_html_e( 'Lead', 'arc-starter-templates' ); ?></th>
					<th><?php esc_html_e( 'Messages', 'arc-starter-templates' ); ?></th>
					<th style="width:60px"></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $conversations as $c ) : ?>
				<tr>
					<td><code><?php echo esc_html( substr( $c['session'], 0, 12 ) ); ?></code></td>
					<td><?php echo esc_html( $c['last'] ); ?></td>
					<td style="word-break:break-all"><?php echo esc_html( wp_parse_url( (string) $c['page'], PHP_URL_PATH ) ?: $c['page'] ); ?></td>
					<td>
						<?php if ( ! empty( $c['lead_email'] ) ) : ?>
							<a href="mailto:<?php echo esc_attr( $c['lead_email'] ); ?>"><?php echo esc_html( $c['lead_email'] ); ?></a>
						<?php else : ?>
							<span style="color:#a7aaad">—</span>
						<?php endif; ?>
					</td>
					<td>
						<details>
							<summary><?php echo esc_html( sprintf( /* translators: %d: lines. */ __( '%d messages', 'arc-starter-templates' ), (int) $c['msg_count'] ) ); ?></summary>
							<div style="padding:8px 0">
								<?php foreach ( $c['messages'] as $msg ) : ?>
									<p style="margin:4px 0">
										<strong style="color:<?php echo 'visitor' === $msg['role'] ? '#2271b1' : '#1d7a4f'; ?>">
											<?php echo 'visitor' === $msg['role'] ? esc_html__( 'Visitor', 'arc-starter-templates' ) : esc_html__( 'Bot', 'arc-starter-templates' ); ?>:
										</strong>
										<?php echo esc_html( $msg['message'] ); ?>
										<em style="color:#a7aaad"><?php echo esc_html( $msg['created'] ); ?></em>
									</p>
								<?php endforeach; ?>
							</div>
						</details>
					</td>
					<td>
						<a class="button button-link-delete" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=arc_st_chat_delete&session=' . $c['session'] ), 'arc_st_chat_delete_' . $c['session'] ) ); ?>"
							onclick="return confirm('<?php echo esc_js( __( 'Delete this conversation?', 'arc-starter-templates' ) ); ?>');">&times;</a>
					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<?php if ( $pages > 1 ) : ?>
		<div class="tablenav"><div class="tablenav-pages">
			<?php
			echo wp_kses_post(
				paginate_links(
					array(
						'base'    => add_query_arg( 'paged', '%#%' ),
						'format'  => '',
						'current' => $paged,
						'total'   => $pages,
					)
				)
			);
			?>
		</div></div>
		<?php endif; ?>
	<?php endif; ?>
</div>

<script>
(function () {
	const tbody = document.querySelector('#arc-chat-pairs tbody');
	document.getElementById('arc-chat-add').addEventListener('click', function () {
		const tr = document.createElement('tr');
		tr.innerHTML = '<td><input type="text" name="chat_kw[]" class="large-text" placeholder="price, pricing, cost" /></td>' +
			'<td><textarea name="chat_a[]" class="large-text" rows="2"></textarea></td>' +
			'<td><button type="button" class="button arc-chat-del">&times;</button></td>';
		tbody.appendChild(tr);
	});
	tbody.addEventListener('click', function (e) {
		if (e.target.classList.contains('arc-chat-del')) {
			e.target.closest('tr').remove();
		}
	});

	// --- "Test the bot" — same accent-folding, whole-word matching the widget
	// runs on the front end, over the pairs currently in the form. -----------
	function arcNorm(s) {
		let out = String(s || '').toLowerCase();
		if (out.normalize) out = out.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
		out = out.replace(/[^\p{L}\p{N}]+/gu, ' ').replace(/\s+/g, ' ').trim();
		return ' ' + out + ' ';
	}

	function arcAnswer(msg) {
		const nmsg = arcNorm(msg);
		let best = null, bestScore = 0, bestLen = 0, hits = [];
		document.querySelectorAll('#arc-chat-pairs tbody tr').forEach(function (tr) {
			const kw = tr.querySelector('input[name="chat_kw[]"]');
			const a = tr.querySelector('textarea[name="chat_a[]"]');
			if (!kw || !a) return;
			let score = 0, len = 0, mine = [];
			kw.value.split(',').map(function (k) { return arcNorm(k).trim(); }).filter(Boolean).forEach(function (k) {
				if (nmsg.includes(' ' + k + ' ')) { score++; len += k.length; mine.push(k); }
			});
			if (score > bestScore || (score === bestScore && score > 0 && len > bestLen)) {
				bestScore = score; bestLen = len; best = a.value; hits = mine;
			}
		});
		return { answer: best, hits: hits, score: bestScore };
	}

	const testIn = document.getElementById('arc-chat-test-in');
	const testOut = document.getElementById('arc-chat-test-out');
	function runTest() {
		const msg = testIn.value.trim();
		if (!msg) return;
		const r = arcAnswer(msg);
		const fallback = document.getElementById('chat_fallback').value;
		const esc = function (s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; };
		testOut.innerHTML = r.score
			? '<div class="notice notice-success inline" style="padding:8px 12px"><p><strong>' +
				'<?php echo esc_js( __( 'Matched', 'arc-starter-templates' ) ); ?>:</strong> ' + esc(r.hits.join(', ')) +
				'</p><p style="margin-top:6px">' + esc(r.answer) + '</p></div>'
			: '<div class="notice notice-warning inline" style="padding:8px 12px"><p><strong>' +
				'<?php echo esc_js( __( 'No keyword matched — fallback fires', 'arc-starter-templates' ) ); ?></strong>' +
				'</p><p style="margin-top:6px">' + esc(fallback) + '</p></div>';
	}
	document.getElementById('arc-chat-test-run').addEventListener('click', runTest);
	testIn.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); runTest(); } });
})();
</script>
